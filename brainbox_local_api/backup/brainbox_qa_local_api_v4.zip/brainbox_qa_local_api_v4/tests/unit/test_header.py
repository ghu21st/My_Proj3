from app.validators import validate_header_exact

def test_validate_header_exact_all_good():
    ok, info = validate_header_exact(["bill_id","meter_id","usage_type","building_id","start_date","end_date"])
    assert ok and info["missing"] == [] and info["extra"] == []

def test_validate_header_exact_extra():
    ok, info = validate_header_exact(["bill_id","meter_id","usage_type","building_id","start_date","end_date","foo"])
    assert ok is False
    assert "foo" in info["extra"]
