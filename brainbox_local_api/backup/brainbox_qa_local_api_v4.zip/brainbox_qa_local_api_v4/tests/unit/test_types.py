from app.validators import validate_basic_types

def test_validate_basic_types_good():
    rows=[{"bill_id":"b1","meter_id":"1","usage_type":"kwh","building_id":"10","start_date":"2024-01-01","end_date":"2024-02-01"}]
    ok, info = validate_basic_types(rows)
    assert ok is True

def test_validate_basic_types_bad_meter():
    rows=[{"bill_id":"b1","meter_id":"x","usage_type":"kwh","building_id":"10","start_date":"2024-01-01","end_date":"2024-02-01"}]
    ok, info = validate_basic_types(rows)
    assert ok is False and info["field"]=="meter_id"
