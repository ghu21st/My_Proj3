from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_validate_missing_and_extra():
    files = {"file": ("bad.csv", b"bill_id,meter_id,usage_type,badcol\n1,2,3,4\n", "text/csv")}
    r = client.post("/validate/", files=files)
    assert r.status_code == 422
    body = r.json()
    assert body["error"] == "InvalidSchema"
    assert "building_id" in body["missing"]
    assert "badcol" in body["extra"]

def test_validate_ok_both_paths():
    header = b"bill_id,meter_id,usage_type,building_id,start_date,end_date\n"
    row = b"b1,1,kwh,10,2024-01-01,2024-02-01\n"
    for path in ("/validate", "/validate/"):
        r = client.post(path, files={"file":("ok.csv", header+row, "text/csv")})
        assert r.status_code == 200
        assert r.json()["message"].startswith("CSV file is valid")

def test_upload_query_roundtrip():
    header = b"bill_id,meter_id,usage_type,building_id,start_date,end_date\n"
    row = b"b1,1,kwh,10,2024-01-01,2024-02-01\n"
    r = client.post("/upload/", files={"file":("ok.csv", header+row, "text/csv")})
    assert r.status_code == 200, r.text
    assert r.json()["rows_inserted"] >= 1

    r2 = client.post("/athena/query/", json={"sql":"SELECT COUNT(*) AS c FROM custom_csv"})
    assert r2.status_code == 200, r2.text
    out = r2.json()
    assert out["columns"] == ["c"]
    assert out["rowcount"] == 1
    assert out["rows"][0][0] >= 1
