REQUIRED_COLUMNS = [
    "bill_id",
    "meter_id",
    "usage_type",
    "building_id",
    "start_date",
    "end_date",
]
